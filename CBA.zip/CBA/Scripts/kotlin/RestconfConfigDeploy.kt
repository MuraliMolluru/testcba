/*
* Copyright © 2019 TechMahindra
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package org.onap.ccsdk.cds.blueprintsprocessor.services.execution.scripts

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ObjectNode
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.JsonNode
import org.onap.ccsdk.cds.blueprintsprocessor.functions.resource.resolution.contentFromResolvedArtifactNB
import org.onap.ccsdk.cds.blueprintsprocessor.functions.resource.resolution.storedContentFromResolvedArtifactNB
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.BlueprintWebClientService.WebClientResponse
import java.io.File
import java.nio.file.Path
import java.nio.file.Paths
import org.apache.commons.io.FilenameUtils
import org.apache.commons.io.IOUtils
import org.apache.http.client.ClientProtocolException
import org.apache.http.client.entity.EntityBuilder
import org.apache.http.client.methods.HttpPost
import org.apache.http.client.methods.HttpUriRequest
import org.apache.http.entity.ContentType
import org.apache.http.message.BasicHeader
import org.onap.ccsdk.cds.blueprintsprocessor.core.api.data.ExecutionServiceInput
import org.onap.ccsdk.cds.blueprintsprocessor.rest.BasicAuthRestClientProperties
import org.onap.ccsdk.cds.blueprintsprocessor.rest.RestClientProperties
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.BasicAuthRestClientService
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.BlueprintWebClientService
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.RestLoggerService
import org.onap.ccsdk.cds.controllerblueprints.core.BluePrintProcessorException
import org.onap.ccsdk.cds.controllerblueprints.core.utils.ArchiveType
import org.onap.ccsdk.cds.controllerblueprints.core.utils.BluePrintArchiveUtils
import org.onap.ccsdk.cds.controllerblueprints.core.utils.JacksonUtils

import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfMountDevice
import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfApplyDeviceConfig
import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfUnMountDevice
import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfDeviceConfig
import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfClientService
import org.onap.ccsdk.cds.blueprintsprocessor.services.execution.AbstractScriptComponentFunction
import org.slf4j.LoggerFactory
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.MediaType
import org.springframework.web.client.RestTemplate
import org.yaml.snakeyaml.Yaml
import java.util.ArrayList
import java.io.IOException

import java.util.Base64
import java.nio.charset.Charset
import java.nio.file.Files
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

import com.fasterxml.jackson.module.kotlin.readValue
import com.fasterxml.jackson.module.kotlin.treeToValue
import com.fasterxml.jackson.module.kotlin.KotlinModule

open class RestconfConfigDeploy : AbstractScriptComponentFunction() {

    private val log = LoggerFactory.getLogger(RestconfConfigDeploy::class.java)!!
    private val CONFIGLET_TEMPLATE_NAME = "config-assign"
    private val CONFIGLET_RESOURCE_PATH = "yang-ext:mount"
    private val RESTCONF_SERVER_IDENTIFIER = "sdnc"
    private val mapper = ObjectMapper()

    override fun getName(): String {
        return "RestconfConfigDeploy"
    }

    override suspend fun processNB(executionRequest: ExecutionServiceInput) {
        log.info("DAY-1 Script excution Started")

        val prefix = "baseconfig"

        val baseK8sApiUrl = getDynamicProperties("api-access").get("url").asText()
        val k8sApiUsername = getDynamicProperties("api-access").get("username").asText()
        val k8sApiPassword = getDynamicProperties("api-access").get("password").asText()

        log.info("Multi-cloud params $baseK8sApiUrl")

        val aaiApiUrl = getDynamicProperties("aai-access").get("url").asText()
        val aaiApiUsername = getDynamicProperties("aai-access").get("username").asText()
        val aaiApiPassword = getDynamicProperties("aai-access").get("password").asText()

        log.info("AAI params $aaiApiUrl")

        val resolution_key = getDynamicProperties("resolution-key").asText()

        //val payload = storedContentFromResolvedArtifactNB(resolution_key, prefix)
		//val payloadObject = JacksonUtils.jsonNode(payload) as ObjectNode

        //val serviceInstanceID: String = getResolvedParameter(payloadObject, "service-instance-id")
        //val vnfID: String = getResolvedParameter(payloadObject, "vnf-id")
         val vnfID: String = requestPayloadActionProperty("config-deploy-properties")?.get(0)?.get("vnf-id")?.textValue()!!
        //log.info("Get serviceInstanceID $serviceInstanceID")
        log.info("Get vnfID $vnfID")

        val vnfUrl = aaiApiUrl + "/aai/v19/network/generic-vnfs/generic-vnf/" + vnfID + "/vf-modules";

        val mapOfHeaders = hashMapOf<String, String>()
        mapOfHeaders.put("Accept", "application/json")
        mapOfHeaders.put("Content-Type", "application/json")
        mapOfHeaders.put("x-FromAppId", "SO")
        mapOfHeaders.put("X-TransactionId", "get_aai_subscr")
        val basicAuthRestClientProperties: BasicAuthRestClientProperties = BasicAuthRestClientProperties()
        basicAuthRestClientProperties.username = aaiApiUsername
        basicAuthRestClientProperties.password = aaiApiPassword
        basicAuthRestClientProperties.url = vnfUrl
        basicAuthRestClientProperties.additionalHeaders =mapOfHeaders
        val basicAuthRestClientService: BasicAuthRestClientService= BasicAuthRestClientService(basicAuthRestClientProperties)
        try {
				val resultOfGet: BlueprintWebClientService.WebClientResponse<String> = basicAuthRestClientService.exchangeResource(HttpMethod.GET.name, "", "")

				val aaiBody = resultOfGet.body
				val aaiPayloadObject = JacksonUtils.jsonNode(aaiBody) as ObjectNode

				for (item in aaiPayloadObject.get("vf-module")) 
				{
				
				

					log.info("item payload Deatils : $item")

					val isItBaseVfModule = item.get("is-base-vf-module").asText()

					if(isItBaseVfModule.toBoolean())
						continue

					val vfModuleID: String = item.get("vf-module-id").asText()

					log.info("AAI Vf-module ID is : $vfModuleID")
					val vfModuleName: String = item.get("vf-module-name").asText()

					log.info("AAI Vf-module ID is : $vfModuleName")
					val vfModuleInvariantID: String = item.get("model-invariant-id").asText()

					log.info("AAI Vf-module Invariant ID is : $vfModuleInvariantID")

					val vfModuleUUID: String = item.get("model-version-id").asText()

					log.info("AAI Vf-module UUID is : $vfModuleUUID")

					val vfModuleInstance: String = item.get("heat-stack-id").asText()

					log.info("AAI Vf-module Heat Stack ID : $vfModuleInstance")

					var delimiter = "/"

					val Instance = vfModuleInstance.split(delimiter)
					val instanceName = Instance[0]
					val instanceID = Instance[1]
					log.info("instance name is : $instanceName")
					log.info("K8S instance ID is : $instanceID")

					val instanceNameNameArray: List<String> = vfModuleName.split("..")
					val typOfVfmodule = instanceNameNameArray[1]
					log.info("Type of vf-module: $typOfVfmodule")

                 
					val instanceAPI = K8sInstanceApi(k8sApiUsername, k8sApiPassword, baseK8sApiUrl, vfModuleInvariantID, vfModuleUUID)
					val netconfhost: NetConfHost = instanceAPI.getInstanceDetails(instanceID, typOfVfmodule)


					log.info("Service IP retrieved " +typOfVfmodule+ " ->"+ netconfhost.ipaddress)
						log.info("Service Port retrieved " +typOfVfmodule+ " ->"+ netconfhost.port)
				
					 log.info("Started execution of RestConf method")
					log.info("Hello from CBA - Success!")
					try {
						// Extract Resolution key & Device ID
						val resolutionKey = getDynamicProperties("resolution-key").asText()
						log.info("resolution_key: $resolutionKey")
						val deviceID: String = vnfID
						log.info("device_id: $deviceID")
						val webclientService = restconfClientService(RESTCONF_SERVER_IDENTIFIER)

							try {
									// Mount the device
									val mountPayload:String = contentFromResolvedArtifactNB("config-deploy")
									
									val payloadObject = JacksonUtils.jsonNode(mountPayload) as ObjectNode
									for (node in payloadObject.get("node").elements()) 
										{
										val nodeObject = node as ObjectNode
										    nodeObject.put("node-id", deviceID)
											//nodeObject.put("netconf-node-topology:host", netconfhost.ipaddress)
										    nodeObject.put("netconf-node-topology:port", netconfhost.port)
											//nodeObject.put("netconf-node-topology:port", 830)
											
											

										}	
									
								    
									val nodeInfo:String = mapper.writeValueAsString(payloadObject);
				                    log.info("Node Info : $nodeInfo")
									log.info("Mounting Device : $deviceID")
									
									log.info("Node Info : $mountPayload")
									
									restconfMountDevice(webclientService, deviceID, nodeInfo, mutableMapOf("Content-Type" to "application/json"))
									//Log the current configuration for the subtree
								    val currentConfig: Any = restconfDeviceConfig(webclientService, deviceID, CONFIGLET_RESOURCE_PATH)
									log.info("Current configuration subtree : $currentConfig")
									//Apply configlet
									val result = restconfApplyDeviceConfig(webclientService, deviceID, CONFIGLET_RESOURCE_PATH,
								    storedContentFromResolvedArtifactNB(resolutionKey, CONFIGLET_TEMPLATE_NAME),
									mutableMapOf("Content-Type" to "application/yang.patch+json")) as WebClientResponse<*>
									val jsonResult = mapper.readTree((result.body).toString())
									if (jsonResult.get("ietf-yang-patch:yang-patch-status").get("errors") != null) {
												log.error("There was an error configuring device")
											} else {
												log.info("Device has been configured succesfully")}
										
								
								} catch (err: Exception) {
										restconfUnMountDevice(webclientService, deviceID, "")
										log.error("an error occurred while configuring device {}", err)} finally {}
						} catch (bpe: BluePrintProcessorException) {log.error("Error looking up server identifier ", bpe)}

					
				}
			log.info("RestConf Script excution completed")
			}
        catch (e: Exception) {
            log.info("Caught exception trying to get the vnf Details!!")
            throw BluePrintProcessorException("${e.message}")}
			
    }
	
	
fun getResolvedParameter(payload: ObjectNode, keyName: String): String {
        for (node in payload.get("resource-accumulator-resolved-data").elements()) {
            if (node.get("param-name").asText().equals(keyName)) {
                return node.get("param-value").asText()
            }
        }
        return ""
    }



    override suspend fun recoverNB(runtimeException: RuntimeException, executionRequest: ExecutionServiceInput) {
        log.info("Executing Recovery")
        bluePrintRuntimeService.getBluePrintError().addError("${runtimeException.message}")
    }

  

    inner class K8sInstanceApi(
            val username: String,
            val password: String,
            val baseUrl: String,
            val definition: String,
            val definitionVersion: String
 ) {


		private val basicAuthRestClientService : BasicAuthRestClientService
        init {
            var mapOfHeaders = hashMapOf<String, String>()
            mapOfHeaders.put("Accept", "application/json")
            mapOfHeaders.put("Content-Type", "application/json")
            mapOfHeaders.put("cache-control", " no-cache")
            mapOfHeaders.put("Accept", "application/json")
            var basicAuthRestClientProperties: BasicAuthRestClientProperties = BasicAuthRestClientProperties()
            basicAuthRestClientProperties.username = username
            basicAuthRestClientProperties.password = password
            basicAuthRestClientProperties.url = "$baseUrl/v1/instance"
            basicAuthRestClientProperties.additionalHeaders = mapOfHeaders

            this.basicAuthRestClientService=BasicAuthRestClientService(basicAuthRestClientProperties)
        }
        
        fun getInstanceDetails(instanceId: String, vfModuleType: String): NetConfHost {
            log.info("Executing K8sInstanceApi.getInsnceDetails")
			
            try {
	            val result: BlueprintWebClientService.WebClientResponse<String> = basicAuthRestClientService.exchangeResource(HttpMethod.GET.name, "/${instanceId}/status", "")
                print(result)
                if (result.status >= 200 && result.status < 300) {
                    log.info("K8s instance details retrieved, processing it for pod instance details")
					
					
					  val statusAPIbody = result.body
                        val statusAPINode: JsonNode = mapper.readTree(statusAPIbody).get("resourcesStatus")
						var size = statusAPINode.size()-1
						log.info("fournd resource status length : $size")
                        for (k in 0..statusAPINode.size()-1 step 1)
                        {
                           // println("I am inside StatusAPI Loop");
                            val resourcesStatusNode: JsonNode = mapper.readTree(statusAPIbody).get("resourcesStatus").get(k).get("GVK")
							val name: String = mapper.readTree(statusAPIbody).get("resourcesStatus").get(k).get("name").asText()
                            val kindValue: String = resourcesStatusNode.get("Kind").asText()
                           /* if (kindValue == "Pod")
                            {
                                val podStatusNode: JsonNode = mapper.readTree(statusAPIbody).get("resourcesStatus").get(k).get("status").get("status")
                                val  podIP: String = podStatusNode.get("podIP").asText()
                                val hostIP:String  = podStatusNode.get("hostIP").asText()
                                log.info("Value of podip: $podIP")
                                log.info("Value of Hostip: $hostIP")
								return podIP
                            }*/
							if (kindValue == "Service")
                            {
                                val podSpecNode: JsonNode = mapper.readTree(statusAPIbody).get("resourcesStatus").get(k).get("status").get("spec")
                                val  serviceIP: String = podSpecNode.get("clusterIP").asText()
								val ports: JsonNode = podSpecNode.get("ports")
								val port: Int = ports.get(0).get("nodePort").asInt()
								//val port: Int = podSpecNode.at("/ports[0]/port").asInt()
                                 var details: NetConfHost= NetConfHost(serviceIP, port)
                                log.info("Value of Cluster IP: $serviceIP")
								log.info("Value of Port: $port")
                              return details
                            }
							

                        }

                    
                } else
                    return NetConfHost("", 0)
            } catch (e: Exception) {
                log.info("Caught exception trying to get k8s instance details")
                throw BluePrintProcessorException("${e.message}")
            }
			return NetConfHost("", 0)

        }

      
    }




class K8sResources {

    var GVK:GVK? = null
    lateinit var Name:String

}

 class GVK {

    var Group:String? = null
    var Version:String? = null
    var Kind:String? = null
}


class StatusResponse {

		var request: Object? =  null
         var ready: Boolean? = null
		 var resourceCount:Int? =  null
		 var K8sResourceStatus: Array<K8sResourceStatus?>? = null
        
		 }
		 
		 
class K8sResourceStatus {
       var name: String? = null
		var GVK:GVK? = null
		var status:Status? = null
}

class Status {
        var Metadata:Object? = null
		var Spec:Object? = null
		var Status:K8sStatus? = null


inner class K8sStatus {
        var conditions: Object? = null
		var containerStatuses:Object? = null
		var hostIP:String? = null
	    var phase:String? = null
		var podIP:String? = null
		var podIPs:Object? = null
		var qosClass:String? = null
		var startTime:String? = null
    
}
}

/*
class Node {
	var nodeId:String? = null
	var netconfNodeTopologyReconnectOnChangedSchema:Boolean = false
      var netconfNodeTopologyPassword:String? = null
      var netconfNodeTopologyUsername:String? = null
      var netconfNodeTopologySleepFactor:Int? = null
      var netconfNodeTopologyPort:Int? = null
      var netconfNodeTopologyTcpOnly:Boolean = false
      var netconfNodeTopologyConnectionTimeoutMillis:Int?= null
      var netconfNodeTopologyMaxConnectionAttempts:Int?= null
      var netconfNodeTopologyHost:String? = null
      var netconfNodeTopologyBetweenAttemptsTimeoutMillis:Int?= null
      var netconfNodeTopologyKeepaliveDelay:Int?= null
    

	override fun toString(): String {
		
      return "[node-id: ${this.nodeId},netconf-node-topology:reconnect-on-changed-schema: ${this.netconfNodeTopologyReconnectOnChangedSchema},netconf-node-topology:password: ${this.netconfNodeTopologyPassword},netconf-node-topology:username: ${this.netconfNodeTopologyUsername},netconf-node-topology:sleep-factor: ${this.netconfNodeTopologySleepFactor},netconf-node-topology:port: ${this.netconfNodeTopologyPort},netconf-node-topology:tcp-only: ${this.netconfNodeTopologyTcpOnly},netconf-node-topology:connection-timeout-millis: ${this.netconfNodeTopologyConnectionTimeoutMillis},netconf-node-topology:max-connection-attempts: ${this.netconfNodeTopologyMaxConnectionAttempts},netconf-node-topology:host: ${this.netconfNodeTopologyHost},netconf-node-topology:between-attempts-timeout-millis: ${this.netconfNodeTopologyBetweenAttemptsTimeoutMillis},netconf-node-topology:keepalive-delay: ${this.netconfNodeTopologyKeepaliveDelay}]"
	}

}
*/


data class NetConfHost(var ipaddress: String, var port: Int)
 

}





fun main(args: Array<String>) {

    val kotlin = RestconfConfigDeploy()

    
}

