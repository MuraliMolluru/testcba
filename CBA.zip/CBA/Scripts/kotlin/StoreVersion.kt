/*
 * Copyright © 2021 DTAG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.onap.ccsdk.cds.blueprintsprocessor.services.execution.scripts

import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ObjectNode
import java.io.File
import java.io.IOException
import java.nio.charset.Charset
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.ArrayList
import java.util.Base64
import java.util.LinkedHashMap
import org.apache.commons.io.IOUtils
import org.apache.http.client.ClientProtocolException
import org.apache.http.client.entity.EntityBuilder
import org.apache.http.client.methods.HttpPost
import org.apache.http.client.methods.HttpUriRequest
import org.apache.http.message.BasicHeader
import org.onap.ccsdk.cds.blueprintsprocessor.core.api.data.ExecutionServiceInput
import org.onap.ccsdk.cds.blueprintsprocessor.rest.BasicAuthRestClientProperties
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.BlueprintWebClientService
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.RestLoggerService
import org.onap.ccsdk.cds.blueprintsprocessor.services.execution.AbstractScriptComponentFunction
import org.onap.ccsdk.cds.controllerblueprints.core.BluePrintProcessorException
import org.onap.ccsdk.cds.controllerblueprints.core.utils.ArchiveType
import org.onap.ccsdk.cds.controllerblueprints.core.utils.BluePrintArchiveUtils
import org.onap.ccsdk.cds.blueprintsprocessor.functions.resource.resolution.storedContentFromResolvedArtifactNB
import org.onap.ccsdk.cds.controllerblueprints.core.utils.JacksonUtils
import org.slf4j.LoggerFactory
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.MediaType
import org.yaml.snakeyaml.Yaml

open class StoreVersion : AbstractScriptComponentFunction() {

    private val log = LoggerFactory.getLogger(StoreVersion::class.java)!!

    override fun getName(): String {
        return "StoreVersion"
    }

    override suspend fun processNB(executionRequest: ExecutionServiceInput) {
        log.info("executing Store Version script")

        val aaiUrl = getDynamicProperties("aai-access").get("url").asText()
        val aaiUsername = getDynamicProperties("aai-access").get("username").asText()
        val aaiPassword = getDynamicProperties("aai-access").get("password").asText()

         
          
        val prefixList: ArrayList<String> = getTemplatePrefixList(executionRequest)
        for (prefix in prefixList) {
		    log.info("Prefix : $prefix")
            if (prefix.toLowerCase().equals("vnf")) {
                log.info("Storing versions in service related to the vnf")
                val assignmentParams = getDynamicProperties("assignment-params")
                val payloadObject = JacksonUtils.jsonNode(assignmentParams.get(prefix).asText()) as ObjectNode		
				val service_day0_version: String = getResolvedParameter(payloadObject, "cucp_cl_test0_day0_version")
				val service_day1_version: String = getResolvedParameter(payloadObject, "cucp_cl_test0_day1_version")
                val vnf_id: String = getResolvedParameter(payloadObject, "vnf-id")
				val vnfUrl: String = aaiUrl +"/aai/v19/network/generic-vnfs/generic-vnf/"+vnf_id
	            val vnf_query_object  = AAIApi(aaiUsername, aaiPassword, vnfUrl)
				val service_link=vnf_query_object.getVnf()
				log.info("Got related service $service_link")
				val service_url =aaiUrl+service_link
				val service_update_object = AAIApi(aaiUsername, aaiPassword,service_url)
				val updated: Boolean = service_update_object.updateService(service_day0_version, service_day1_version)
				if(updated) log.info("Store Version Successful") else log.info("Store Version Failed.")
				
            }
			
        }
    }

    fun getTemplatePrefixList(executionRequest: ExecutionServiceInput): ArrayList<String> {
        val result = ArrayList<String>()
        for (prefix in executionRequest.payload.get("resource-assignment-request").get("template-prefix").elements())
            result.add(prefix.asText())
        return result
    }
	
    fun getResolvedParameter(payload: ObjectNode, keyName: String): String {
        for (node in payload.get("resource-accumulator-resolved-data").elements()) {
            if (node.get("param-name").asText().equals(keyName)) {
                return node.get("param-value").asText()
            }
        }
        return ""
    }

    fun getResolvedParameterbyCapabilityData(payload: ObjectNode, keyName: String): String {
        for (node in payload.get("capability-data").elements()) {
            log.info("node: $node")
            if (node.get("capability-name").asText().equals("unresolved-composite-data")) {
                log.info("inside")
                for (d in node.get("key-mapping")) {
                    log.info("d: $d")
                    for (value in d.get("output-key-mapping")) {
                        if (value.get("resource-name").asText().equals(keyName)) {
                            log.info("value: $value")
                            return value.get("resource-value").asText()
                        }
                    }
                }
            }
        }
        return ""
    }

    override suspend fun recoverNB(runtimeException: RuntimeException, executionRequest: ExecutionServiceInput) {
        log.info("Executing Recovery")
        bluePrintRuntimeService.getBluePrintError().addError("${runtimeException.message}")
    }

    inner class AAIApi(
        val username: String,
        val password: String,
        val aaiUrl: String
		
    ) {
        private val service: AAIRestClientService // BasicAuthRestClientService

        init {
            var mapOfHeaders = hashMapOf<String, String>()
            mapOfHeaders.put("Accept", "application/json")
            mapOfHeaders.put("Content-Type", "application/json")
            mapOfHeaders.put("cache-control", " no-cache")
            mapOfHeaders.put("Accept", "application/json")
			mapOfHeaders.put("x-fromappid", "CDS")
		    mapOfHeaders.put("x-transactionid", "11117")
            var basicAuthRestClientProperties: BasicAuthRestClientProperties = BasicAuthRestClientProperties()
            basicAuthRestClientProperties.username = username
            basicAuthRestClientProperties.password = password
            basicAuthRestClientProperties.url = aaiUrl
            basicAuthRestClientProperties.additionalHeaders = mapOfHeaders

            this.service = AAIRestClientService(basicAuthRestClientProperties)
        }

        fun getVnf(): String {
		    
            try {
                val result: BlueprintWebClientService.WebClientResponse<String> = service.exchangeResource(HttpMethod.GET.name, "", "")
                print(result)
				val body = result.body
			
            
			
                val payloadObject = JacksonUtils.jsonNode(body) as ObjectNode
                	
                for(rel in payloadObject.get("relationship-list").get("relationship"))
					{
					 var to=rel.get("related-to").asText()
					 log.info("Searching for relationship..$to")
					if(to.equals("service-instance"))
						{
						var serviceName = rel.get("related-link").asText()
						log.info("Found service-instance $serviceName")
						return serviceName
						
						}
					

					}
				
                }catch (e: Exception) {
                log.info("Caught exception trying to get VNF")
                throw BluePrintProcessorException("${e.message}")
            }
			return ""
        }
		
		 fun updateService(day0: String, day1: String): Boolean {
            try {
                val result: BlueprintWebClientService.WebClientResponse<String> = service.exchangeResource(HttpMethod.GET.name, "", "")
                print(result)
				val body = result.body
			
               val payloadObject = JacksonUtils.jsonNode(body) as ObjectNode
                
				   var workload_context:String = day0+","+day1	
				   var serviceName = payloadObject.get("service-instance-name")
				   log.info("Updating version in service $serviceName to $workload_context")
	               payloadObject.put("workload-context", workload_context)
				   
				   val resultPUT: BlueprintWebClientService.WebClientResponse<String> = service.exchangeResource(HttpMethod.PUT.name, "", payloadObject.toString())
	               log.info("********Update result  : $resultPUT*****")
				    if (resultPUT.status >= 200 && resultPUT.status < 300)
                    return true
                else
                    return false
                		
				}
				
                catch (e: Exception) {
                log.info("Caught exception trying to store version")
                throw BluePrintProcessorException("${e.message}")
            }
        }

    }
}

class AAIRestClientService(
    private val restClientProperties:
        BasicAuthRestClientProperties
) : BlueprintWebClientService {

    override fun defaultHeaders(): Map<String, String> {

        val encodedCredentials = setBasicAuth(
            restClientProperties.username,
            restClientProperties.password
        )
        return mapOf(
            HttpHeaders.CONTENT_TYPE to MediaType.APPLICATION_JSON_VALUE,
            HttpHeaders.ACCEPT to MediaType.APPLICATION_JSON_VALUE,
            HttpHeaders.AUTHORIZATION to "Basic $encodedCredentials"
        )
    }

    override fun host(uri: String): String {
        return restClientProperties.url + uri
    }

    override fun convertToBasicHeaders(headers: Map<String, String>):
        Array<BasicHeader> {
            val customHeaders: MutableMap<String, String> = headers.toMutableMap()
            // inject additionalHeaders
            customHeaders.putAll(verifyAdditionalHeaders(restClientProperties))

            if (!headers.containsKey(HttpHeaders.AUTHORIZATION)) {
                val encodedCredentials = setBasicAuth(
                    restClientProperties.username,
                    restClientProperties.password
                )
                customHeaders[HttpHeaders.AUTHORIZATION] =
                    "Basic $encodedCredentials"
            }
            return super.convertToBasicHeaders(customHeaders)
        }

    private fun setBasicAuth(username: String, password: String): String {
        val credentialsString = "$username:$password"
        return Base64.getEncoder().encodeToString(
            credentialsString.toByteArray(Charset.defaultCharset())
        )
    }

    @Throws(IOException::class, ClientProtocolException::class)
    private fun performHttpCall(httpUriRequest: HttpUriRequest): BlueprintWebClientService.WebClientResponse<String> {
        val httpResponse = httpClient().execute(httpUriRequest)
        val statusCode = httpResponse.statusLine.statusCode
        httpResponse.entity.content.use {
            val body = IOUtils.toString(it, Charset.defaultCharset())
            return BlueprintWebClientService.WebClientResponse(statusCode, body)
        }
    }

}


