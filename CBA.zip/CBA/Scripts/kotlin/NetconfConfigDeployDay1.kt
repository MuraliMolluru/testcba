/*
* ============LICENSE_START=======================================================
*  Copyright (C) 2020 Nordix Foundation.
* ================================================================================
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* ============LICENSE_END=========================================================
 */


package org.onap.ccsdk.cds.blueprintsprocessor.services.execution.scripts


import org.onap.ccsdk.cds.blueprintsprocessor.core.api.data.ExecutionServiceInput
import org.onap.ccsdk.cds.blueprintsprocessor.functions.resource.resolution.storedContentFromResolvedArtifactNB
import org.onap.ccsdk.cds.blueprintsprocessor.services.execution.AbstractScriptComponentFunction
import org.onap.ccsdk.cds.controllerblueprints.core.BluePrintProcessorException
import org.slf4j.LoggerFactory
import org.onap.ccsdk.cds.blueprintsprocessor.functions.netconf.executor.netconfDevice
import org.onap.ccsdk.cds.blueprintsprocessor.functions.netconf.executor.netconfDeviceInfo
import org.springframework.dao.EmptyResultDataAccessException
import org.onap.ccsdk.cds.controllerblueprints.core.BluePrintException
import org.onap.ccsdk.cds.blueprintsprocessor.functions.netconf.executor.api.NetconfException
import org.onap.ccsdk.cds.blueprintsprocessor.functions.netconf.executor.utils.NetconfMessageUtils
import org.onap.ccsdk.cds.blueprintsprocessor.functions.netconf.executor.api.DeviceResponse



class NetconfConfigDeployDay1 : AbstractScriptComponentFunction() {
    private val log = LoggerFactory.getLogger(NetconfConfigDeployDay1::class.java)
    private val GPP_CONFIG_PREFIX = "3GPP.xml"
    private val VENDOR_CONFIG_PREFIX = "VS.xml"
    private val ARTIFACT_NAME = "day-1"

    /**
     * Method to deploy the provided YANG file to CNF
     */
    fun verifyYang(yangFile: String): Boolean {
        return false
    }

    fun deployYang(yangFile: String) {
    }

    override suspend fun processNB(executionRequest: ExecutionServiceInput) {

        log.info("Started execution of process method")

        // Check if parameters are correctly passed
        if((getDynamicProperties("nfId") == null || getDynamicProperties("nfId").isNull()) || (getDynamicProperties("version") == null || getDynamicProperties("version").isNull())) {
            throw BluePrintProcessorException("Invalid parameters sent to CDS. Request parameters nfId or version are missing or not correct!")
        }

        // Get the nfId provided as an input.
        val nfId = getDynamicProperties("nfId").asText()
        log.info("Got the resolution_key: $nfId from config-deploy-day-1 going to retrive the data from DB")

        // Get the version provided as an input.
        val version = getDynamicProperties("version").asText()
        log.info("Got the version: $version from config-deploy-day-1 going to retrive the data from DB")
/*
        // Create resolution-keys for different type of configs
        var gpp_config_name = "${nfId}_${GPP_CONFIG_PREFIX}_${version}"
        var vendor_config_name = "${nfId}_${VENDOR_CONFIG_PREFIX}_${version}"

        log.info("Got config_name for 3gpp-config: $gpp_config_name")
        log.info("Got config_name for vendor-config: $vendor_config_name")

        // Extract configurations from CDS-DB

        val gpp_config = getConfigFromDB(gpp_config_name, ARTIFACT_NAME)
        val vendor_config = getConfigFromDB(vendor_config_name, ARTIFACT_NAME)

        log.info("CNF - CUUP configuration (3gpp-specific) : \n$gpp_config\n")
        log.info("CNF - CUUP configuration (vendor-specific): \n$vendor_config\n")

        // Create netconf connection.
        try {
            val netconf_device = netconfDevice("netconf-connection")
            val netconf_rpc_client = netconf_device.netconfRpcService
            val netconf_session = netconf_device.netconfSession
            netconf_session.connect()

            val gpp_response = netconf_rpc_client.editConfig(gpp_config, "running", "replace")
            //netconf_rpc_client.commit()
            checkNetconfResponse(gpp_response, gpp_config_name)

            val vendor_response = netconf_rpc_client.editConfig(vendor_config, "running", "replace")
            //netconf_rpc_client.commit()
            checkNetconfResponse(vendor_response, vendor_config_name)

            log.info("Closing NETCONF device session with the device\n")
            netconf_session.disconnect()
        } catch (e : NetconfException) {
            // Thrown in case that no netconf connection could be established
            throw BluePrintProcessorException("${e.message}")
        }*/
    }

    override suspend fun recoverNB(runtimeException: RuntimeException, executionRequest: ExecutionServiceInput) {
        log.info("Recover function called!")
        log.info("Execution request : $executionRequest")
        log.error("Exception", runtimeException)
        bluePrintRuntimeService.getBluePrintError().addError("${runtimeException.message}")
    }

    suspend fun getConfigFromDB(resolution_key: String, artifact_name: String): String {
        try {
            return storedContentFromResolvedArtifactNB(resolution_key, artifact_name)
        } catch (e: EmptyResultDataAccessException) {
            val blueprintName = bluePrintRuntimeService.bluePrintContext().name()
            val blueprintVersion = bluePrintRuntimeService.bluePrintContext().version()
            throw BluePrintProcessorException("Artifact (resolution_key: $resolution_key, artifact_name: $artifact_name, blueprint_name: $blueprintName, blueprint_version: $blueprintVersion) not available in CDS-DB!")
        }
    }

    suspend fun checkNetconfResponse(netconf_response: DeviceResponse, config_name: String) {
        // check status of response
        if (!netconf_response.isSuccess()) {
            throw NetconfException("Config ${config_name} could not be applied correctly.")
        }
    }
}