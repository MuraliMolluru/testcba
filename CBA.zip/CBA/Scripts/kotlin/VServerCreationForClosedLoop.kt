/*
* Copyright © 2019 TechMahindra
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package org.onap.ccsdk.cds.blueprintsprocessor.services.execution.scripts

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ObjectNode
import java.io.File
import java.nio.file.Path
import java.nio.file.Paths
import org.apache.commons.io.FilenameUtils
import org.apache.commons.io.IOUtils
import org.apache.http.client.ClientProtocolException
import org.apache.http.client.entity.EntityBuilder
import org.apache.http.client.methods.HttpPost
import org.apache.http.client.methods.HttpUriRequest
import org.apache.http.entity.ContentType
import org.apache.http.message.BasicHeader
import org.onap.ccsdk.cds.blueprintsprocessor.core.api.data.ExecutionServiceInput
import org.onap.ccsdk.cds.blueprintsprocessor.rest.BasicAuthRestClientProperties
import org.onap.ccsdk.cds.blueprintsprocessor.rest.RestClientProperties
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.BasicAuthRestClientService
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.BlueprintWebClientService
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.RestLoggerService
import org.onap.ccsdk.cds.blueprintsprocessor.services.execution.AbstractScriptComponentFunction
import org.onap.ccsdk.cds.controllerblueprints.core.BluePrintProcessorException
import org.onap.ccsdk.cds.controllerblueprints.core.utils.ArchiveType
import org.onap.ccsdk.cds.controllerblueprints.core.utils.BluePrintArchiveUtils
import org.onap.ccsdk.cds.controllerblueprints.core.utils.JacksonUtils
import org.onap.ccsdk.cds.blueprintsprocessor.functions.resource.resolution.storedContentFromResolvedArtifactNB
import org.slf4j.LoggerFactory
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.MediaType
import org.springframework.web.client.RestTemplate
import org.yaml.snakeyaml.Yaml
import java.util.ArrayList
import java.io.IOException
import java.util.UUID

import java.util.Base64
import java.nio.charset.Charset
import java.nio.file.Files
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

open class VServerCreationForClosedLoop : AbstractScriptComponentFunction() {

    private val log = LoggerFactory.getLogger(VServerCreationForClosedLoop::class.java)!!

    override fun getName(): String {
        return "VServerCreationForClosedLoop"
    }

    override suspend fun processNB(executionRequest: ExecutionServiceInput) {
        log.info("V-Server for Closed Loop being created in AAI")

        try{

          val aaiApiUrl = getDynamicProperties("aai-access").get("url").asText()
          val baseUrl =  getDynamicProperties("aai-access").get("aaiVersion").asText()
          val aaiApiUsername = getDynamicProperties("aai-access").get("username").asText()
          val aaiApiPassword = getDynamicProperties("aai-access").get("password").asText()
		  val resolution_key = getDynamicProperties("resolution-key").asText()

       
        

        
         val vnfID: String = requestPayloadActionProperty("config-deploy-properties")?.get(0)?.get("vnf-id")?.textValue()!!

         



            val vnfUrl = aaiApiUrl + baseUrl +"/network/generic-vnfs/generic-vnf/" + vnfID + "?depth=all";
            val vnf_query_object  = AAIApi(aaiApiUsername ,aaiApiPassword , vnfUrl)
            val resultOfGet : String = vnf_query_object.getVnf()

            val aaiPayloadObject = JacksonUtils.jsonNode(resultOfGet) as ObjectNode
            var tenant:String =""
            for (rel in aaiPayloadObject.get("relationship-list").get("relationship")) {

                if(rel.get("related-to").asText().equals("tenant"))
                    tenant = rel.get("related-link").asText()



            }



            for (item in aaiPayloadObject.get("vf-modules").get("vf-module")) {

                log.info("item payload Deatils : $item")

                val isItBaseVfModule = item.get("is-base-vf-module").asText()

                if(isItBaseVfModule.toBoolean())
                    continue

                val vfModuleID: String = item.get("vf-module-id").asText()
                log.info("AAI Vf-module ID is : $vfModuleID")

                val vfModuleInvariantID: String = item.get("model-invariant-id").asText()

                log.info("AAI Vf-module Invariant ID is : $vfModuleInvariantID")

                val vfModuleUUID: String = item.get("model-version-id").asText()

                log.info("AAI Vf-module UUID is : $vfModuleUUID")

                val vfModuleInstance: String = item.get("heat-stack-id").asText()

                log.info("AAI Vf-module Heat Stack ID : $vfModuleInstance")

                
               
                var uuid :String =  UUID.randomUUID().toString()
                var vlink: String = tenant +"/vservers/vserver/"+uuid

                var vserverlink = aaiApiUrl + vlink
                val vserver_create_object  = AAIApi(aaiApiUsername ,aaiApiPassword ,vserverlink)
                val created : Boolean = vserver_create_object.createVserver(baseUrl,vlink,  vnfID, vfModuleID, vfModuleInstance, uuid)


            }
            log.info("VServer creation in AAI completed")
        }
        catch (e: Exception) {
            log.info("Caught exception trying to get the vnf Details!!")
            throw BluePrintProcessorException("${e.message}")
        }
    }


    fun getResolvedParameter(payload: ObjectNode, keyName: String): String {
        for (node in payload.get("resource-accumulator-resolved-data").elements()) {
            if (node.get("param-name").asText().equals(keyName)) {
                return node.get("param-value").asText()
            }
        }
        return ""
    }
    override suspend fun recoverNB(runtimeException: RuntimeException, executionRequest: ExecutionServiceInput) {
        log.info("Executing Recovery")
        bluePrintRuntimeService.getBluePrintError().addError("${runtimeException.message}")
    }


    inner class AAIApi(
            val username: String,
            val password: String,
            val aaiUrl: String

    ) {
        private val service: AAIRestClient // BasicAuthRestClientService

        init {
            var mapOfHeaders = hashMapOf<String, String>()
            mapOfHeaders.put("Accept", "application/json")
            mapOfHeaders.put("Content-Type", "application/json")
            mapOfHeaders.put("cache-control", " no-cache")
            mapOfHeaders.put("Accept", "application/json")
            mapOfHeaders.put("x-fromappid", "CDS")
            mapOfHeaders.put("x-transactionid", "11117")
            var basicAuthRestClientProperties: BasicAuthRestClientProperties = BasicAuthRestClientProperties()
            basicAuthRestClientProperties.username = username
            basicAuthRestClientProperties.password = password
            basicAuthRestClientProperties.url = aaiUrl
            basicAuthRestClientProperties.additionalHeaders = mapOfHeaders

            this.service = AAIRestClient(basicAuthRestClientProperties)
        }

        fun getVnf(): String {

            try {
                val result: BlueprintWebClientService.WebClientResponse<String> = service.exchangeResource(HttpMethod.GET.name, "", "")
                print(result)
                val body = result.body

                return body.toString()


            }catch (e: Exception) {
                log.info("Caught exception trying to get VNF")
                throw BluePrintProcessorException("${e.message}")
            }
            return ""
        }

        fun createVserver( aaiUrl:String, vserverlink:String,  vnfID: String, vfModuleID: String, name: String , uuid:String) :Boolean {
            try {


                var vf_link : String = aaiUrl+"/network/generic-vnfs/generic-vnf/"+vnfID+"/vf-modules/vf-module/"+vfModuleID
				var vnf_link : String = aaiUrl+"/network/generic-vnfs/generic-vnf/"+vnfID
                val result:String ="{\"vserver-id\": \"\",\"vserver-name\": \"\",\"vserver-selflink\": \"\",\"relationship-list\": {\"relationship\": [{\"related-to\": \"vf-module\",\"relationship-label\": \"org.onap.relationships.inventory.Uses\",\"related-link\": \"\"},{\"related-to\": \"generic-vnf\",\"related-link\": \"\"}]}}"
                var payloadObject = JacksonUtils.jsonNode(result) as ObjectNode
                log.info(payloadObject.get("vserver-id").asText())
                payloadObject.put("vserver-id",uuid)
                log.info(payloadObject.get("vserver-id").asText())
				payloadObject.put("vserver-name", name)
                payloadObject.put("vserver-selflink" , vserverlink)
                for (rel in payloadObject.get("relationship-list").get("relationship")) {
                    if(rel.get("related-to").asText().equals("vf-module")) {
                         var r1 = rel as ObjectNode
                        r1.put("related-link", vf_link)

                    }
					if(rel.get("related-to").asText().equals("generic-vnf")) {
                         var r2 = rel as ObjectNode
                        r2.put("related-link", vnf_link)

                    }

                }



                val resultPUT: BlueprintWebClientService.WebClientResponse<String> = service.exchangeResource(HttpMethod.PUT.name, "", payloadObject.toString())
                log.info("********Update result  : $resultPUT*****")
                if (resultPUT.status >= 200 && resultPUT.status < 300)
                    return true
                else
                    return false

            }

            catch (e: Exception) {
                log.info("Caught exception trying to store version")
                throw BluePrintProcessorException("${e.message}")
            }
        }

    }
}

class AAIRestClient(
        private val restClientProperties:
        BasicAuthRestClientProperties
) : BlueprintWebClientService {

    override fun defaultHeaders(): Map<String, String> {

        val encodedCredentials = setBasicAuth(
                restClientProperties.username,
                restClientProperties.password
        )
        return mapOf(
                HttpHeaders.CONTENT_TYPE to MediaType.APPLICATION_JSON_VALUE,
                HttpHeaders.ACCEPT to MediaType.APPLICATION_JSON_VALUE,
                HttpHeaders.AUTHORIZATION to "Basic $encodedCredentials"
        )
    }

    override fun host(uri: String): String {
        return restClientProperties.url + uri
    }

    override fun convertToBasicHeaders(headers: Map<String, String>):
            Array<BasicHeader> {
        val customHeaders: MutableMap<String, String> = headers.toMutableMap()
        // inject additionalHeaders
        customHeaders.putAll(verifyAdditionalHeaders(restClientProperties))

        if (!headers.containsKey(HttpHeaders.AUTHORIZATION)) {
            val encodedCredentials = setBasicAuth(
                    restClientProperties.username,
                    restClientProperties.password
            )
            customHeaders[HttpHeaders.AUTHORIZATION] =
                    "Basic $encodedCredentials"
        }
        return super.convertToBasicHeaders(customHeaders)
    }

    private fun setBasicAuth(username: String, password: String): String {
        val credentialsString = "$username:$password"
        return Base64.getEncoder().encodeToString(
                credentialsString.toByteArray(Charset.defaultCharset())
        )
    }

    @Throws(IOException::class, ClientProtocolException::class)
    private fun performHttpCall(httpUriRequest: HttpUriRequest): BlueprintWebClientService.WebClientResponse<String> {
        val httpResponse = httpClient().execute(httpUriRequest)
        val statusCode = httpResponse.statusLine.statusCode
        httpResponse.entity.content.use {
            val body = IOUtils.toString(it, Charset.defaultCharset())
            return BlueprintWebClientService.WebClientResponse(statusCode, body)
        }
    }

}

