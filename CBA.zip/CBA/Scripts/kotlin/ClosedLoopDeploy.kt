/*
* ============LICENSE_START=======================================================
*  Copyright (C) 2020 Nordix Foundation.
* ================================================================================
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* ============LICENSE_END=========================================================
 */


package org.onap.ccsdk.cds.blueprintsprocessor.services.execution.scripts


import org.onap.ccsdk.cds.blueprintsprocessor.core.api.data.ExecutionServiceInput
import org.onap.ccsdk.cds.blueprintsprocessor.functions.resource.resolution.contentFromResolvedArtifactNB
import org.onap.ccsdk.cds.blueprintsprocessor.functions.resource.resolution.storedContentFromResolvedArtifactNB
import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfMountDevice
import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfApplyDeviceConfig
import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfUnMountDevice
import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfDeviceConfig
import org.onap.ccsdk.cds.blueprintsprocessor.functions.restconf.executor.restconfClientService
import org.onap.ccsdk.cds.blueprintsprocessor.services.execution.AbstractScriptComponentFunction
import org.onap.ccsdk.cds.controllerblueprints.core.BluePrintProcessorException
import org.onap.ccsdk.cds.controllerblueprints.core.logger
import com.fasterxml.jackson.databind.ObjectMapper
import org.onap.ccsdk.cds.blueprintsprocessor.rest.service.BlueprintWebClientService.WebClientResponse
import org.onap.ccsdk.cds.blueprintsprocessor.functions.netconf.executor.netconfDevice

class ClosedLoopDeploy : AbstractScriptComponentFunction() {
    
    private val log = logger(AbstractScriptComponentFunction::class.java)

   

   

    override suspend fun processNB(executionRequest: ExecutionServiceInput) {

        log.info("STARTED EXECUTION OF CLOSED LOOP ACTION")
        try {
            // Get the service-instance-id provided as an input.
            val service_instance_id = getDynamicProperties("service-instance-id").asText()
            log.info("********CLOSED LOOP ACTION FOR SERVICE : $service_instance_id**************")
            val administrativeState = getDynamicProperties("administrativeState").asText()
			log.info("********CLOSED LOOP ACTION FOR administrativeState : $administrativeState**************")
			val subscriptionName = getDynamicProperties("subscriptionName").asText()
			log.info("********CLOSED LOOP ACTION FOR subscriptionName : $subscriptionName**************")
			val fileBasedGP = getDynamicProperties("fileBasedGP").asText()
			log.info("********CLOSED LOOP ACTION FOR fileBasedGP : $fileBasedGP**************")
			val fileLocation = getDynamicProperties("fileLocation").asText()
			log.info("********CLOSED LOOP ACTION FOR fileLocation : $fileLocation**************")
        } catch (bpe: BluePrintProcessorException) {
            log.error("Error : ", bpe)
        }
    }

    override suspend fun recoverNB(runtimeException: RuntimeException, executionRequest: ExecutionServiceInput) {
        log.info("Recover function called!")
        log.info("Execution request : $executionRequest")
        log.error("Exception", runtimeException)
    }
}